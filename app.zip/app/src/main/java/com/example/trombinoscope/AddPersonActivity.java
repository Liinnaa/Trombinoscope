package com.example.trombinoscope;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.example.trombinoscope.DAO.PersonDAOData;
import com.example.trombinoscope.DTO.Person;

import java.util.Random;


public class AddPersonActivity extends AppCompatActivity {

    Button btn_add;
    String nom, prenom;

    EditText nomText, prenomText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_person);

        nomText = (EditText) findViewById(R.id.add_nom);
        prenomText = (EditText) findViewById(R.id.add_prenom);
        btn_add = (Button) findViewById(R.id.ajout_personne);
        btn_add.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        nom = nomText.getText().toString();
                        prenom = prenomText.getText().toString();
                        Random rnd = new Random();
                        int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));

                        Person person = new Person(prenom, nom, color);
                        PersonDAOData list = new PersonDAOData();
                        list.addPerson(person);
                        Toast.makeText(getApplicationContext(), "Ajout fait", Toast.LENGTH_LONG).show();
                        Intent activityChangeIntent = new Intent(AddPersonActivity.this, MainActivity.class);
                        AddPersonActivity.this.startActivity(activityChangeIntent);
                    }
                }
        );
    }
}
