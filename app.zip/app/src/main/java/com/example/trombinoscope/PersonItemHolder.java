package com.example.trombinoscope;

import android.widget.ImageView;
import android.widget.TextView;

public class PersonItemHolder {
    public TextView   firstName;
    public TextView lastName;
    public  ImageView avatar;
}
